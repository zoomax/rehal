export const SET_PLACES = "SET_PLACES";
export const ADD_PLACE = "ADD_PLACE";
export const UPDATE_PLACE = "UPDATE_PLACE";
export const DELETE_PLACE = "DELETE_PLACE";
